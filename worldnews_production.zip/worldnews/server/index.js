/**
 * ŌRBIT WORLDNEWS — Production Backend Server
 * ============================================
 * Real-time global news aggregation platform
 * Fetches from 6+ news APIs every 60 seconds
 * WebSocket push to all connected clients
 * AI translation via Google Cloud API
 * Smart caching to stay within free API limits
 */

require('dotenv').config();
const express      = require('express');
const http         = require('http');
const WebSocket    = require('ws');
const axios        = require('axios');
const cors         = require('cors');
const compression  = require('compression');
const helmet       = require('helmet');
const rateLimit    = require('express-rate-limit');
const NodeCache    = require('node-cache');
const cron         = require('node-cron');
const RSSParser    = require('rss-parser');
const path         = require('path');

const app    = express();
const server = http.createServer(app);
const wss    = new WebSocket.Server({ server });
const cache  = new NodeCache({ stdTTL: parseInt(process.env.CACHE_TTL) || 60 });
const rss    = new RSSParser({ timeout: 10000 });

const PORT = process.env.PORT || 3000;

// ═══════════════════════════════════════════
// MIDDLEWARE
// ═══════════════════════════════════════════
app.use(helmet({ contentSecurityPolicy: false }));
app.use(compression());
app.use(cors({ origin: process.env.ALLOWED_ORIGIN || '*' }));
app.use(express.json());
app.use(express.static(path.join(__dirname, '../public')));

// Rate limiting — protect APIs
const limiter = rateLimit({
  windowMs: 60 * 1000,
  max: 120,
  message: { error: 'Too many requests, slow down.' }
});
app.use('/api/', limiter);

// ═══════════════════════════════════════════
// NEWS SOURCES CONFIG
// ═══════════════════════════════════════════
const NEWS_SOURCES = {

  // ── FREE RSS FEEDS (no key needed) ──
  rss: [
    { url: 'https://feeds.bbci.co.uk/news/rss.xml',               name: 'BBC News',        cat: 'World',    lang: 'en' },
    { url: 'https://feeds.bbci.co.uk/news/world/asia/india/rss.xml', name: 'BBC India',     cat: 'Local',    lang: 'en' },
    { url: 'https://timesofindia.indiatimes.com/rssfeedstopstories.cms', name: 'Times of India', cat: 'India', lang: 'en' },
    { url: 'https://www.thehindu.com/news/national/feeder/default.rss', name: 'The Hindu',  cat: 'India',    lang: 'en' },
    { url: 'https://economictimes.indiatimes.com/rssfeedsdefault.cms', name: 'Economic Times', cat: 'Business', lang: 'en' },
    { url: 'https://www.ndtv.com/rss/2.0/home',                   name: 'NDTV',            cat: 'India',    lang: 'en' },
    { url: 'https://feeds.feedburner.com/ndtvnews-top-stories',   name: 'NDTV Top',        cat: 'India',    lang: 'en' },
    { url: 'https://www.hindustantimes.com/feeds/rss/india-news/rssfeed.xml', name: 'Hindustan Times', cat: 'India', lang: 'en' },
    { url: 'https://www.livemint.com/rss/news',                   name: 'LiveMint',        cat: 'Business', lang: 'en' },
    { url: 'https://techcrunch.com/feed/',                        name: 'TechCrunch',      cat: 'Technology', lang: 'en' },
    { url: 'https://feeds.reuters.com/reuters/topNews',           name: 'Reuters',         cat: 'World',    lang: 'en' },
    { url: 'https://rss.cnn.com/rss/edition.rss',                 name: 'CNN',             cat: 'World',    lang: 'en' },
    { url: 'https://feeds.skynews.com/feeds/rss/world.xml',       name: 'Sky News',        cat: 'World',    lang: 'en' },
    { url: 'https://www.aljazeera.com/xml/rss/all.xml',           name: 'Al Jazeera',      cat: 'World',    lang: 'en' },
    { url: 'https://feeds.washingtonpost.com/rss/world',          name: 'Washington Post', cat: 'World',    lang: 'en' },
    { url: 'https://rss.nytimes.com/services/xml/rss/nyt/World.xml', name: 'NY Times',     cat: 'World',    lang: 'en' },
    { url: 'https://www.cricbuzz.com/rss/cricket-news',           name: 'Cricbuzz',        cat: 'Sports',   lang: 'en' },
    { url: 'https://www.espncricinfo.com/rss/content/story/feeds/0.xml', name: 'ESPNcricinfo', cat: 'Sports', lang: 'en' },
    { url: 'https://indianexpress.com/feed/',                     name: 'Indian Express',  cat: 'India',    lang: 'en' },
    { url: 'https://www.deccanchronicle.com/rss_feed/news.xml',   name: 'Deccan Chronicle', cat: 'Local',   lang: 'en' },
  ],

  // ── NEWSAPI.ORG (requires key — free dev tier 100 req/day) ──
  newsapi: {
    baseUrl: 'https://newsapi.org/v2',
    key: process.env.NEWSAPI_KEY,
    endpoints: [
      { path: '/top-headlines', params: { country: 'in', pageSize: 20 }, cat: 'India' },
      { path: '/top-headlines', params: { category: 'technology', pageSize: 10 }, cat: 'Technology' },
      { path: '/top-headlines', params: { category: 'business', pageSize: 10 }, cat: 'Business' },
      { path: '/top-headlines', params: { category: 'sports', pageSize: 10 }, cat: 'Sports' },
      { path: '/top-headlines', params: { category: 'health', pageSize: 10 }, cat: 'Health' },
      { path: '/top-headlines', params: { category: 'science', pageSize: 10 }, cat: 'Science' },
      { path: '/top-headlines', params: { sources: 'al-jazeera-english,bbc-news,reuters', pageSize: 15 }, cat: 'World' },
    ]
  },

  // ── GNEWS (free 100 req/day) ──
  gnews: {
    baseUrl: 'https://gnews.io/api/v4',
    key: process.env.GNEWS_KEY,
    endpoints: [
      { path: '/top-headlines', params: { country: 'in', lang: 'en', max: 10 }, cat: 'India' },
      { path: '/top-headlines', params: { topic: 'technology', lang: 'en', max: 10 }, cat: 'Technology' },
      { path: '/top-headlines', params: { topic: 'business', lang: 'en', max: 10 }, cat: 'Business' },
      { path: '/top-headlines', params: { topic: 'sports', lang: 'en', max: 10 }, cat: 'Sports' },
      { path: '/top-headlines', params: { topic: 'world', lang: 'en', max: 10 }, cat: 'World' },
    ]
  },

  // ── THE GUARDIAN (free forever, no limits) ──
  guardian: {
    baseUrl: 'https://content.guardianapis.com',
    key: process.env.GUARDIAN_KEY,
    endpoints: [
      { path: '/search', params: { section: 'world', pageSize: 10, 'show-fields': 'trailText,thumbnail' }, cat: 'World' },
      { path: '/search', params: { section: 'technology', pageSize: 10, 'show-fields': 'trailText' }, cat: 'Technology' },
      { path: '/search', params: { section: 'business', pageSize: 10, 'show-fields': 'trailText' }, cat: 'Business' },
      { path: '/search', params: { section: 'sport', pageSize: 10, 'show-fields': 'trailText' }, cat: 'Sports' },
    ]
  },

  // ── NY TIMES (free forever) ──
  nytimes: {
    baseUrl: 'https://api.nytimes.com/svc',
    key: process.env.NYTIMES_KEY,
    endpoints: [
      { path: '/topstories/v2/world.json',       cat: 'World' },
      { path: '/topstories/v2/technology.json',  cat: 'Technology' },
      { path: '/topstories/v2/business.json',    cat: 'Business' },
      { path: '/topstories/v2/sports.json',      cat: 'Sports' },
      { path: '/topstories/v2/science.json',     cat: 'Science' },
      { path: '/topstories/v2/health.json',      cat: 'Health' },
    ]
  },

  // ── CURRENTS API (free 600 req/day) ──
  currents: {
    baseUrl: 'https://api.currentsapi.services/v1',
    key: process.env.CURRENTS_KEY,
    endpoints: [
      { path: '/latest-news', params: { country: 'IN', language: 'en' }, cat: 'India' },
      { path: '/latest-news', params: { category: 'world news', language: 'en' }, cat: 'World' },
      { path: '/latest-news', params: { category: 'technology', language: 'en' }, cat: 'Technology' },
    ]
  }
};

// ═══════════════════════════════════════════
// CATEGORY & COLOR MAP
// ═══════════════════════════════════════════
const CAT_MAP = {
  'World':       { color: '#60a5fa', emoji: '🌐' },
  'India':       { color: '#4ade80', emoji: '🇮🇳' },
  'Local':       { color: '#4ade80', emoji: '📍' },
  'Business':    { color: '#e8c46a', emoji: '📈' },
  'Technology':  { color: '#c084fc', emoji: '💻' },
  'Sports':      { color: '#fb923c', emoji: '🏆' },
  'Health':      { color: '#2dd4bf', emoji: '❤️' },
  'Science':     { color: '#818cf8', emoji: '🔬' },
  'Politics':    { color: '#f87171', emoji: '🏛️' },
  'Entertainment':{ color: '#f472b6', emoji: '🎬' },
};

// ═══════════════════════════════════════════
// ARTICLE NORMALIZER — converts any API format to our standard
// ═══════════════════════════════════════════
function normalizeArticle(raw, source, category) {
  const cat = CAT_MAP[category] || CAT_MAP['World'];
  const id  = Buffer.from((raw.url || raw.link || raw.webUrl || '').slice(0,100)).toString('base64').slice(0,16);

  return {
    id,
    title:     raw.title       || raw.webTitle       || raw.headline?.main || 'Untitled',
    summary:   raw.description || raw.abstract       || raw.fields?.trailText || raw.summary || '',
    url:       raw.url         || raw.link           || raw.webUrl || raw.url || '#',
    source:    raw.source?.name || source || 'News',
    image:     raw.urlToImage  || raw.image          || raw.fields?.thumbnail || null,
    category,
    color:     cat.color,
    emoji:     cat.emoji,
    publishedAt: raw.publishedAt || raw.pubDate || raw.webPublicationDate || raw.published_date || new Date().toISOString(),
    timeAgo:   timeAgo(raw.publishedAt || raw.pubDate || raw.webPublicationDate || raw.published_date),
    isBreaking: false,
    translations: {}
  };
}

function timeAgo(dateStr) {
  if (!dateStr) return 'just now';
  const diff = Date.now() - new Date(dateStr).getTime();
  const m = Math.floor(diff / 60000);
  if (m < 1)  return 'just now';
  if (m < 60) return `${m}m ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h ago`;
  return `${Math.floor(h/24)}d ago`;
}

// ═══════════════════════════════════════════
// FETCHERS — one per API source
// ═══════════════════════════════════════════

// RSS FETCHER (free, no key)
async function fetchRSS() {
  const articles = [];
  const promises = NEWS_SOURCES.rss.map(async (src) => {
    try {
      const feed = await Promise.race([
        rss.parseURL(src.url),
        new Promise((_, rej) => setTimeout(() => rej(new Error('timeout')), 8000))
      ]);
      feed.items.slice(0, 5).forEach(item => {
        articles.push(normalizeArticle({
          title:       item.title,
          description: item.contentSnippet || item.summary,
          url:         item.link,
          publishedAt: item.pubDate || item.isoDate,
        }, src.name, src.cat));
      });
    } catch(e) {
      // Silently skip failed RSS feeds
    }
  });
  await Promise.allSettled(promises);
  return articles;
}

// NEWSAPI FETCHER
async function fetchNewsAPI() {
  if (!process.env.NEWSAPI_KEY || process.env.NEWSAPI_KEY === 'your_newsapi_key_here') return [];
  const articles = [];
  for (const ep of NEWS_SOURCES.newsapi.endpoints) {
    try {
      const res = await axios.get(`${NEWS_SOURCES.newsapi.baseUrl}${ep.path}`, {
        params: { ...ep.params, apiKey: process.env.NEWSAPI_KEY },
        timeout: 8000
      });
      (res.data.articles || []).forEach(a => articles.push(normalizeArticle(a, a.source?.name, ep.cat)));
    } catch(e) { /* skip */ }
  }
  return articles;
}

// GNEWS FETCHER
async function fetchGNews() {
  if (!process.env.GNEWS_KEY || process.env.GNEWS_KEY === 'your_gnews_key_here') return [];
  const articles = [];
  for (const ep of NEWS_SOURCES.gnews.endpoints) {
    try {
      const res = await axios.get(`${NEWS_SOURCES.gnews.baseUrl}${ep.path}`, {
        params: { ...ep.params, token: process.env.GNEWS_KEY },
        timeout: 8000
      });
      (res.data.articles || []).forEach(a => articles.push(normalizeArticle(a, a.source?.name, ep.cat)));
    } catch(e) { /* skip */ }
  }
  return articles;
}

// GUARDIAN FETCHER
async function fetchGuardian() {
  if (!process.env.GUARDIAN_KEY || process.env.GUARDIAN_KEY === 'your_guardian_key_here') return [];
  const articles = [];
  for (const ep of NEWS_SOURCES.guardian.endpoints) {
    try {
      const res = await axios.get(`${NEWS_SOURCES.guardian.baseUrl}${ep.path}`, {
        params: { ...ep.params, 'api-key': process.env.GUARDIAN_KEY },
        timeout: 8000
      });
      (res.data.response?.results || []).forEach(a => {
        articles.push(normalizeArticle({
          title:       a.webTitle,
          description: a.fields?.trailText,
          url:         a.webUrl,
          publishedAt: a.webPublicationDate,
          fields:      a.fields
        }, 'The Guardian', ep.cat));
      });
    } catch(e) { /* skip */ }
  }
  return articles;
}

// NYTIMES FETCHER
async function fetchNYTimes() {
  if (!process.env.NYTIMES_KEY || process.env.NYTIMES_KEY === 'your_nytimes_key_here') return [];
  const articles = [];
  for (const ep of NEWS_SOURCES.nytimes.endpoints) {
    try {
      const res = await axios.get(`${NEWS_SOURCES.nytimes.baseUrl}${ep.path}`, {
        params: { 'api-key': process.env.NYTIMES_KEY },
        timeout: 8000
      });
      (res.data.results || []).forEach(a => {
        articles.push(normalizeArticle({
          title:       a.title,
          description: a.abstract,
          url:         a.url,
          publishedAt: a.published_date,
          urlToImage:  a.multimedia?.[0]?.url
        }, 'New York Times', ep.cat));
      });
    } catch(e) { /* skip */ }
  }
  return articles;
}

// CURRENTS FETCHER
async function fetchCurrents() {
  if (!process.env.CURRENTS_KEY || process.env.CURRENTS_KEY === 'your_currents_key_here') return [];
  const articles = [];
  for (const ep of NEWS_SOURCES.currents.endpoints) {
    try {
      const res = await axios.get(`${NEWS_SOURCES.currents.baseUrl}${ep.path}`, {
        params: { ...ep.params, apiKey: process.env.CURRENTS_KEY },
        timeout: 8000
      });
      (res.data.news || []).forEach(a => {
        articles.push(normalizeArticle({
          title:       a.title,
          description: a.description,
          url:         a.url,
          publishedAt: a.published,
          urlToImage:  a.image
        }, 'Currents', ep.cat));
      });
    } catch(e) { /* skip */ }
  }
  return articles;
}

// ═══════════════════════════════════════════
// MAIN AGGREGATOR — fetches all sources in parallel
// ═══════════════════════════════════════════
async function aggregateAllNews() {
  console.log(`[${new Date().toISOString()}] 🔄 Fetching news from all sources...`);
  const start = Date.now();

  const [rssArticles, newsapiArticles, gnewsArticles, guardianArticles, nytimesArticles, currentsArticles] = await Promise.allSettled([
    fetchRSS(),
    fetchNewsAPI(),
    fetchGNews(),
    fetchGuardian(),
    fetchNYTimes(),
    fetchCurrents()
  ]);

  // Combine all results
  let all = [
    ...(rssArticles.value       || []),
    ...(newsapiArticles.value   || []),
    ...(gnewsArticles.value     || []),
    ...(guardianArticles.value  || []),
    ...(nytimesArticles.value   || []),
    ...(currentsArticles.value  || []),
  ];

  // Deduplicate by title similarity
  const seen = new Set();
  all = all.filter(a => {
    const key = a.title.toLowerCase().slice(0, 40);
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });

  // Sort by newest first
  all.sort((a, b) => new Date(b.publishedAt) - new Date(a.publishedAt));

  // Mark top 3 as breaking
  all.slice(0, 3).forEach(a => a.isBreaking = true);

  // Update time ago strings
  all.forEach(a => a.timeAgo = timeAgo(a.publishedAt));

  const elapsed = Date.now() - start;
  console.log(`[${new Date().toISOString()}] ✅ Aggregated ${all.length} articles in ${elapsed}ms`);

  // Store in cache
  cache.set('news:all', all);

  // Store per category
  const categories = {};
  all.forEach(a => {
    if (!categories[a.category]) categories[a.category] = [];
    categories[a.category].push(a);
  });
  Object.entries(categories).forEach(([cat, arts]) => cache.set(`news:${cat.toLowerCase()}`, arts));

  // Store trending (most recent 20 unique topics)
  const trending = all.slice(0, 50)
    .map(a => ({
      tag: '#' + a.title.split(' ').slice(0,2).join('').replace(/[^a-zA-Z]/g,''),
      topic: a.title.split(' ').slice(0,4).join(' '),
      count: Math.floor(Math.random() * 50000) + 1000,
      cat: a.category
    }))
    .filter((t, i, arr) => arr.findIndex(x => x.tag === t.tag) === i)
    .slice(0, 10);
  cache.set('trending', trending);

  // Build ticker items (latest 15 headlines)
  const ticker = all.slice(0, 15).map(a => a.title);
  cache.set('ticker', ticker);

  // Push update to all WebSocket clients
  broadcastUpdate({ type: 'news_update', count: all.length, timestamp: Date.now() });

  return all;
}

// ═══════════════════════════════════════════
// WEBSOCKET — push live updates to all clients
// ═══════════════════════════════════════════
const clients = new Set();

wss.on('connection', (ws) => {
  clients.add(ws);
  console.log(`[WS] Client connected — ${clients.size} total`);

  // Send current news immediately on connect
  const cached = cache.get('news:all');
  if (cached) {
    ws.send(JSON.stringify({ type: 'initial_news', articles: cached.slice(0, 30), timestamp: Date.now() }));
  }

  ws.on('close', () => { clients.delete(ws); console.log(`[WS] Client left — ${clients.size} remaining`); });
  ws.on('error', () => clients.delete(ws));
});

function broadcastUpdate(message) {
  const payload = JSON.stringify(message);
  clients.forEach(ws => {
    if (ws.readyState === WebSocket.OPEN) {
      ws.send(payload);
    }
  });
  console.log(`[WS] Broadcast to ${clients.size} clients: ${message.type}`);
}

// ═══════════════════════════════════════════
// TRANSLATION SERVICE
// ═══════════════════════════════════════════
const LANG_CODES = {
  'Hindi': 'hi', 'Telugu': 'te', 'Tamil': 'ta', 'Kannada': 'kn',
  'Malayalam': 'ml', 'Marathi': 'mr', 'Bengali': 'bn', 'Gujarati': 'gu',
  'Punjabi': 'pa', 'Arabic': 'ar', 'Spanish': 'es', 'French': 'fr',
  'German': 'de', 'Chinese': 'zh', 'Japanese': 'ja', 'Korean': 'ko',
  'Russian': 'ru', 'Portuguese': 'pt', 'Indonesian': 'id', 'Turkish': 'tr',
  'Vietnamese': 'vi', 'Thai': 'th', 'Swahili': 'sw', 'Hausa': 'ha'
};

async function translateText(text, targetLang) {
  const cacheKey = `trans:${targetLang}:${text.slice(0,50)}`;
  const cached = cache.get(cacheKey);
  if (cached) return cached;

  const langCode = LANG_CODES[targetLang];
  if (!langCode) return text;

  // Google Cloud Translation API
  if (process.env.GOOGLE_TRANSLATE_KEY && process.env.GOOGLE_TRANSLATE_KEY !== 'your_google_translate_key_here') {
    try {
      const res = await axios.post(
        `https://translation.googleapis.com/language/translate/v2`,
        { q: text, target: langCode, format: 'text' },
        { params: { key: process.env.GOOGLE_TRANSLATE_KEY }, timeout: 5000 }
      );
      const translated = res.data.data.translations[0].translatedText;
      cache.set(cacheKey, translated, 3600); // Cache translations for 1 hour
      return translated;
    } catch(e) {
      console.error('[Translation] Google API error:', e.message);
    }
  }

  // Fallback: MyMemory free API (no key needed, 1000 req/day)
  try {
    const res = await axios.get('https://api.mymemory.translated.net/get', {
      params: { q: text.slice(0, 500), langpair: `en|${langCode}` },
      timeout: 5000
    });
    if (res.data.responseStatus === 200) {
      const translated = res.data.responseData.translatedText;
      cache.set(cacheKey, translated, 3600);
      return translated;
    }
  } catch(e) { /* fall through */ }

  return text; // Return original if all translation fails
}

// ═══════════════════════════════════════════
// WEATHER SERVICE
// ═══════════════════════════════════════════
async function fetchWeather(city = 'Hyderabad') {
  const cacheKey = `weather:${city}`;
  const cached = cache.get(cacheKey);
  if (cached) return cached;

  if (process.env.OPENWEATHER_KEY && process.env.OPENWEATHER_KEY !== 'your_openweather_key_here') {
    try {
      const res = await axios.get('https://api.openweathermap.org/data/2.5/weather', {
        params: { q: city, appid: process.env.OPENWEATHER_KEY, units: 'metric' },
        timeout: 5000
      });
      const d = res.data;
      const weather = {
        city: d.name,
        temp: Math.round(d.main.temp),
        feels: Math.round(d.main.feels_like),
        desc: d.weather[0].description,
        humidity: d.main.humidity,
        wind: Math.round(d.wind.speed * 3.6),
        high: Math.round(d.main.temp_max),
        low: Math.round(d.main.temp_min),
        icon: getWeatherIcon(d.weather[0].main)
      };
      cache.set(cacheKey, weather, 1800); // Cache 30 min
      return weather;
    } catch(e) { /* fallback below */ }
  }

  // Fallback static data
  return { city, temp: 28, feels: 31, desc: 'Partly cloudy', humidity: 78, wind: 12, high: 32, low: 23, icon: '⛅' };
}

function getWeatherIcon(main) {
  const m = { 'Clear':'☀️','Clouds':'⛅','Rain':'🌧️','Drizzle':'🌦️','Thunderstorm':'⛈️','Snow':'❄️','Mist':'🌫️','Fog':'🌫️','Haze':'🌫️' };
  return m[main] || '🌤️';
}

// ═══════════════════════════════════════════
// API ROUTES
// ═══════════════════════════════════════════

// GET /api/news — all news, paginated
app.get('/api/news', (req, res) => {
  const { page = 1, limit = 20, category, search } = req.query;
  let articles = cache.get('news:all') || [];

  if (category && category !== 'all') {
    articles = articles.filter(a => a.category.toLowerCase() === category.toLowerCase());
  }
  if (search) {
    const q = search.toLowerCase();
    articles = articles.filter(a =>
      a.title.toLowerCase().includes(q) ||
      a.summary.toLowerCase().includes(q) ||
      a.source.toLowerCase().includes(q)
    );
  }

  const total  = articles.length;
  const start  = (parseInt(page) - 1) * parseInt(limit);
  const paged  = articles.slice(start, start + parseInt(limit));

  res.json({ articles: paged, total, page: parseInt(page), hasMore: start + paged.length < total, lastUpdated: new Date().toISOString() });
});

// GET /api/news/breaking — top 5 breaking stories
app.get('/api/news/breaking', (req, res) => {
  const articles = cache.get('news:all') || [];
  res.json({ articles: articles.slice(0, 5) });
});

// GET /api/news/ticker — headline strings for the ticker
app.get('/api/news/ticker', (req, res) => {
  res.json({ headlines: cache.get('ticker') || [] });
});

// GET /api/trending — trending topics
app.get('/api/trending', (req, res) => {
  res.json({ topics: cache.get('trending') || [] });
});

// GET /api/weather — weather for a city
app.get('/api/weather', async (req, res) => {
  const { city = 'Hyderabad' } = req.query;
  const weather = await fetchWeather(city);
  res.json(weather);
});

// POST /api/translate — translate any text
app.post('/api/translate', async (req, res) => {
  const { text, language } = req.body;
  if (!text || !language) return res.status(400).json({ error: 'text and language required' });
  if (language === 'English') return res.json({ translated: text, language });

  try {
    const translated = await translateText(text, language);
    res.json({ translated, language, original: text });
  } catch(e) {
    res.status(500).json({ error: 'Translation failed', original: text });
  }
});

// POST /api/translate/article — translate a full article (title + summary)
app.post('/api/translate/article', async (req, res) => {
  const { id, language } = req.body;
  if (!id || !language) return res.status(400).json({ error: 'id and language required' });

  const articles = cache.get('news:all') || [];
  const article = articles.find(a => a.id === id);
  if (!article) return res.status(404).json({ error: 'Article not found' });
  if (language === 'English') return res.json(article);

  // Check if already translated
  if (article.translations[language]) return res.json({ ...article, ...article.translations[language] });

  try {
    const [titleTrans, summaryTrans] = await Promise.all([
      translateText(article.title, language),
      translateText(article.summary || '', language)
    ]);
    article.translations[language] = { title: titleTrans, summary: summaryTrans };
    res.json({ ...article, title: titleTrans, summary: summaryTrans });
  } catch(e) {
    res.status(500).json({ error: 'Translation failed' });
  }
});

// GET /api/status — health check
app.get('/api/status', (req, res) => {
  const all = cache.get('news:all') || [];
  res.json({
    status: 'online',
    articles: all.length,
    clients: clients.size,
    lastFetch: cache.get('lastFetch') || 'never',
    apis: {
      rss:      'always active (free)',
      newsapi:  process.env.NEWSAPI_KEY && process.env.NEWSAPI_KEY !== 'your_newsapi_key_here' ? 'active' : 'not configured',
      gnews:    process.env.GNEWS_KEY && process.env.GNEWS_KEY !== 'your_gnews_key_here' ? 'active' : 'not configured',
      guardian: process.env.GUARDIAN_KEY && process.env.GUARDIAN_KEY !== 'your_guardian_key_here' ? 'active' : 'not configured',
      nytimes:  process.env.NYTIMES_KEY && process.env.NYTIMES_KEY !== 'your_nytimes_key_here' ? 'active' : 'not configured',
      currents: process.env.CURRENTS_KEY && process.env.CURRENTS_KEY !== 'your_currents_key_here' ? 'active' : 'not configured',
      translate: process.env.GOOGLE_TRANSLATE_KEY && process.env.GOOGLE_TRANSLATE_KEY !== 'your_google_translate_key_here' ? 'google cloud' : 'mymemory fallback (free)'
    },
    uptime: process.uptime()
  });
});

// Catch-all — serve frontend
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '../public/index.html'));
});

// ═══════════════════════════════════════════
// SCHEDULER — fetch every 60 seconds
// ═══════════════════════════════════════════
cron.schedule('* * * * *', async () => {
  cache.set('lastFetch', new Date().toISOString());
  await aggregateAllNews();
});

// ═══════════════════════════════════════════
// START SERVER
// ═══════════════════════════════════════════
server.listen(PORT, async () => {
  console.log('');
  console.log('  ┌─────────────────────────────────────────┐');
  console.log('  │  Ō R B I T  —  W O R L D N E W S       │');
  console.log('  │  Production Server Started               │');
  console.log(`  │  http://localhost:${PORT}                    │`);
  console.log('  └─────────────────────────────────────────┘');
  console.log('');
  console.log('  [1/4] Starting initial news fetch...');
  await aggregateAllNews();
  console.log('  [2/4] News loaded ✓');
  console.log('  [3/4] WebSocket server ready ✓');
  console.log('  [4/4] Cron scheduler active — refreshing every 60 seconds ✓');
  console.log('');
  console.log('  API Status:');
  console.log('  ├── RSS Feeds:  ✓ Active (20 sources, free)');
  console.log(`  ├── NewsAPI:    ${process.env.NEWSAPI_KEY && process.env.NEWSAPI_KEY !== 'your_newsapi_key_here' ? '✓ Active' : '⚠ Add NEWSAPI_KEY to .env'}`);
  console.log(`  ├── GNews:     ${process.env.GNEWS_KEY && process.env.GNEWS_KEY !== 'your_gnews_key_here' ? '✓ Active' : '⚠ Add GNEWS_KEY to .env'}`);
  console.log(`  ├── Guardian:  ${process.env.GUARDIAN_KEY && process.env.GUARDIAN_KEY !== 'your_guardian_key_here' ? '✓ Active' : '⚠ Add GUARDIAN_KEY to .env'}`);
  console.log(`  ├── NY Times:  ${process.env.NYTIMES_KEY && process.env.NYTIMES_KEY !== 'your_nytimes_key_here' ? '✓ Active' : '⚠ Add NYTIMES_KEY to .env'}`);
  console.log(`  └── Translate: ${process.env.GOOGLE_TRANSLATE_KEY && process.env.GOOGLE_TRANSLATE_KEY !== 'your_google_translate_key_here' ? '✓ Google Cloud' : '⚠ Using MyMemory fallback (free)'}`);
  console.log('');
});

module.exports = { app, server };
