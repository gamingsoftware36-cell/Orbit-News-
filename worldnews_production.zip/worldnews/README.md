# ŌRBIT WORLDNEWS — Complete Deployment Guide

## What You Have
- **Node.js backend** — fetches from 20+ news sources every 60 seconds
- **WebSocket server** — pushes live updates to all users instantly  
- **REST API** — 8 endpoints for news, translation, weather, trending
- **Production frontend** — luxury UI that connects to your live backend
- **Free RSS feeds** — works with ZERO API keys (BBC, Reuters, NDTV, etc.)
- **Optional paid APIs** — add keys to get even more sources

---

## STEP 1 — Install Node.js (if you don't have it)

Download from: https://nodejs.org (choose LTS version)

Verify installation:
```bash
node --version   # Should show v18 or higher
npm --version    # Should show 9 or higher
```

---

## STEP 2 — Set Up The Project

```bash
# Extract the worldnews folder, then:
cd worldnews

# Install all dependencies
npm install

# Copy the environment file
cp .env.example .env
```

---

## STEP 3 — Get Your FREE API Keys (15 minutes)

### RSS Feeds (ZERO keys needed — works immediately)
The app already pulls from 20 sources with no signup:
BBC, Reuters, NDTV, Times of India, The Hindu, Economic Times,
TechCrunch, Al Jazeera, CNN, Sky News, Cricbuzz, and more.

### NewsAPI.org (FREE — 100 requests/day)
1. Go to: https://newsapi.org/register
2. Sign up with email
3. Copy your API key
4. Add to .env: `NEWSAPI_KEY=your_key_here`

### The Guardian (FREE — unlimited)
1. Go to: https://open-platform.theguardian.com/access/
2. Click "Register for a developer key"
3. Add to .env: `GUARDIAN_KEY=your_key_here`

### NY Times (FREE — unlimited)
1. Go to: https://developer.nytimes.com/
2. Create account → Create App → Enable "Top Stories API"
3. Add to .env: `NYTIMES_KEY=your_key_here`

### GNews (FREE — 100 requests/day)
1. Go to: https://gnews.io/
2. Sign up → copy API key
3. Add to .env: `GNEWS_KEY=your_key_here`

### OpenWeatherMap (FREE — 1000 calls/day)
1. Go to: https://openweathermap.org/api
2. Sign up → API Keys tab → copy key
3. Add to .env: `OPENWEATHER_KEY=your_key_here`

### Google Translate (FREE — 500,000 chars/month)
1. Go to: https://console.cloud.google.com/
2. Create project → Enable "Cloud Translation API"
3. Create credentials → API Key
4. Add to .env: `GOOGLE_TRANSLATE_KEY=your_key_here`

---

## STEP 4 — Run Locally (Test First)

```bash
cd worldnews
node server/index.js
```

You should see:
```
  ┌─────────────────────────────────────────┐
  │  Ō R B I T  —  W O R L D N E W S       │
  │  Production Server Started               │
  │  http://localhost:3000                   │
  └─────────────────────────────────────────┘
  [1/4] Starting initial news fetch...
  [2/4] News loaded ✓
  [3/4] WebSocket server ready ✓
  [4/4] Cron scheduler active — refreshing every 60 seconds ✓
```

Open browser: http://localhost:3000
**Your app is live with real news!**

---

## STEP 5 — Deploy to Internet (FREE hosting)

### Option A: Railway.app (EASIEST — recommended)

1. Go to https://railway.app — sign up free
2. Click "New Project" → "Deploy from GitHub"
3. Push your worldnews folder to GitHub first:
   ```bash
   git init
   git add .
   git commit -m "Orbit WorldNews"
   git push origin main
   ```
4. Railway auto-detects Node.js and deploys
5. Go to Settings → Variables → add all your .env keys
6. Your app gets a free URL: `https://worldnews-xxx.railway.app`

**Railway free tier:** 500 hours/month (enough for 24/7)

### Option B: Render.com (also FREE)

1. Go to https://render.com — sign up
2. New → Web Service → Connect GitHub repo
3. Build Command: `npm install`
4. Start Command: `node server/index.js`
5. Add environment variables in the dashboard
6. Deploy — get URL: `https://worldnews-xxx.onrender.com`

### Option C: Your Own VPS (best performance)

If you have a VPS (DigitalOcean, AWS, etc.):
```bash
# Upload files via SCP or Git
git clone your-repo

cd worldnews
npm install
cp .env.example .env
nano .env  # Add your keys

# Install PM2 to keep it running 24/7
npm install -g pm2
pm2 start server/index.js --name orbit
pm2 startup  # Auto-restart on reboot
pm2 save
```

---

## STEP 6 — Update Frontend URL

Once deployed, update the frontend to point to your server.

In `public/index.html`, the `API_BASE` automatically uses `window.location.origin`
so if your frontend and backend are on the same server — it just works!

If you host frontend separately (Vercel, Netlify):
Change line in index.html:
```javascript
const API_BASE = 'https://your-railway-url.railway.app';
const WS_URL   = 'wss://your-railway-url.railway.app';
```

---

## API ENDPOINTS (for reference)

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/news` | GET | All news (params: page, limit, category, search) |
| `/api/news/breaking` | GET | Top 5 breaking stories |
| `/api/news/ticker` | GET | Headlines for ticker |
| `/api/trending` | GET | Trending topics |
| `/api/weather` | GET | Weather (param: city) |
| `/api/translate` | POST | Translate text (body: {text, language}) |
| `/api/translate/article` | POST | Translate article (body: {id, language}) |
| `/api/status` | GET | Server health check |

---

## ADDING MORE NEWS SOURCES

Edit `server/index.js` — add RSS feeds to the `NEWS_SOURCES.rss` array:

```javascript
{ url: 'https://your-news-source.com/rss.xml', name: 'My Source', cat: 'World', lang: 'en' },
```

Any website with an RSS feed can be added instantly — for FREE.

---

## COST BREAKDOWN

| Service | Free Tier | Cost if exceeded |
|---------|-----------|------------------|
| Railway hosting | 500 hrs/month | $5/month |
| RSS feeds (20 sources) | Unlimited | Free forever |
| NewsAPI | 100 req/day | $449/month |
| The Guardian API | Unlimited | Free forever |
| NY Times API | Unlimited | Free forever |
| GNews | 100 req/day | $10/month |
| OpenWeather | 1,000/day | $40/month |
| Google Translate | 500K chars/month | $20/million chars |

**To start: $0/month. RSS + Guardian + NYTimes = unlimited free news.**

---

## TROUBLESHOOTING

**"Cannot connect to server"**
→ Make sure `node server/index.js` is running
→ Check PORT in .env matches (default 3000)

**"No articles loading"**
→ Check terminal for errors
→ RSS feeds work without any keys — check internet connection

**"Translation not working"**
→ Add GOOGLE_TRANSLATE_KEY to .env
→ MyMemory fallback (free) should work automatically

**"WebSocket disconnecting"**
→ Normal on free hosting — auto-reconnects every 3 seconds

---

## NEXT STEPS TO MAKE IT EVEN BETTER

1. **Add authentication** — Firebase Auth or Auth0 (free tier)
2. **Add database** — Supabase PostgreSQL (free tier) to save user preferences
3. **Add push notifications** — Firebase Cloud Messaging (free)
4. **Add mobile app** — React Native using the same API
5. **Add more languages** — Just add RSS feeds in regional languages
6. **Monetize** — Add Google AdSense or local business ads

---

*Built with Node.js, Express, WebSockets, and 20+ free news APIs*
*Ōrbit WorldNews — Real news. Every minute. Every language.*
